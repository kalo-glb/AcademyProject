﻿using System;

namespace KingSurvivalGame
{
    public class Engine
    {
        protected static int MovesCounter = 0;
        protected static bool GameIsOver = false;

        /// <summary>
        /// Check coordinates
        /// </summary>
        /// <param name="positionCoordinates">Coordinates to check</param>
        /// <returns>Return a boolean value is coordinates valid</returns>
        protected static bool CheckCoordinates(int[] positionCoordinates)
        {
            int firstCoordinates = positionCoordinates[0];
            bool isFirstCoordinatesValid = (firstCoordinates >= Field.GameEdges[0, 0]) &&
                (firstCoordinates <= Field.GameEdges[3, 0]);

            int secondCoordinates = positionCoordinates[1];
            bool isSecondCoordinatesValid = (secondCoordinates >= Field.GameEdges[0, 1]) &&
                (secondCoordinates <= Field.GameEdges[3, 1]);

            bool result = isFirstCoordinatesValid && isSecondCoordinatesValid;
            return result;
        }

        /// <summary>
        /// Write Game Field in Console and change
        /// Background and Foreground colors of Game Field
        /// </summary>
        public static void GetField()
        {
            for (int row = 0; row < Field.GameField.GetLength(0); row++)
            {
                for (int col = 0; col < Field.GameField.GetLength(1); col++)
                {
                    int[] coordinates = { row, col };
                    bool isCellIn = King.CheckCoordinates(coordinates);
                    if (isCellIn)
                    {
                        if (row % 2 == 0)
                        {
                            if (col % 4 == 0)
                            {
                                SetGreenColor(row, col);
                            }
                            else if (col % 2 == 0)
                            {
                                SetBlueColor(row, col);
                            }
                            else if (col % 2 != 0)
                            {
                                Console.Write(Field.GameField[row, col]);
                            }
                        }
                        else if (col % 4 == 0)
                        {
                            SetBlueColor(row, col);
                        }
                        else if (col % 2 == 0)
                        {
                            SetGreenColor(row, col);
                        }
                        else if (col % 2 != 0)
                        {
                            Console.Write(Field.GameField[row, col]);
                        }
                    }
                    else
                    {
                        Console.Write(Field.GameField[row, col]);
                    }
                }
                Console.WriteLine();
                Console.ResetColor();
            }
        }

        /// <summary>
        /// Set the color of the element blue.
        /// </summary>
        /// <param name="row">Element's row</param>
        /// <param name="col">Element's col</param>
        private static void SetBlueColor(int row, int col)
        {
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Write(Field.GameField[row, col]);
            Console.ResetColor();
        }

        /// <summary>
        /// Set the color of the element green.
        /// </summary>
        /// <param name="row">Element's row</param>
        /// <param name="col">Element's col</param>
        private static void SetGreenColor(int row, int col)
        {
            Console.BackgroundColor = ConsoleColor.Green;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Write(Field.GameField[row, col]);
            Console.ResetColor();
        }

        /// <summary>
        /// Start game
        /// </summary>
        /// <param name="moveCounter">Get count of moves</param>
        protected static void Start(int moveCounter)
        {
            if (GameIsOver)
            {
                Console.WriteLine("Game is finished!");
            }
            else
            {
                if (moveCounter % 2 == 0)
                {
                    GetField();
                    ProcessFigure('K');
                }
                else
                {
                    GetField();
                    ProcessFigure('P');
                }
            }
        }

        /// <summary>
        /// Check Commands Exist
        /// </summary>
        /// <param name="checkedString">String to check</param>
        /// <returns>Return a boolean value true if command exist</returns>
        /// <returns>Return a boolean value false if command do not exist</returns>
        static bool CheckCommandsExist(string checkedString)
        {
            bool isValid = false;
            for (int i = 0; i < Field.ValidInputs.Length; i++)
            {
                string reference = Field.ValidInputs[i];
                int result = checkedString.CompareTo(reference);
                if (result == 0)
                {
                    isValid = true;
                    break;
                }
            }

            if (!isValid)
            {
                Console.BackgroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid command name!");
                Console.ResetColor();
            }

            return isValid;
        }

        /// <summary>
        /// Make a move with king or pawn by given command.
        /// </summary>
        /// <param name="command">The command that will be checked and executed.</param>
        /// <param name="isExecuted">If the move is made successfully return true, else false.</param>
        public static void ExecuteCommand(string command, out bool isExecuted)
        {
            // Make command in uppercase - for the tests
            command = command.ToUpper();

            bool isCommandExist = CheckCommandsExist(command);
            if (isCommandExist)
            {
                char figureLetter = command[0];
                char verticalDirection = command[1];
                char horizontalDirection = command[2];

                if (figureLetter == 'K')
                {
                    King.MoveKing(verticalDirection, horizontalDirection);
                }
                else
                {
                    Pawn.MovePawn(figureLetter, horizontalDirection);
                }

                isExecuted = true;
            }
            else
            {
                isExecuted = false;
                // throw new FormatException("The command was not in the right format.");
            }
        }

        /// <summary>
        /// Moves the game figures symbol (A, B, C, D or K) to its next position
        /// </summary>
        /// <param name="currentCoordinates">The coordinates the figure is currently on</param>
        /// <param name="newCoords">The new coordinates for the figure</param>
        protected static void UpdateFigureSymbolOnTheField(int[] currentCoordinates, int[] newCoords)
        {
            char pawnSymbol = Field.GameField[currentCoordinates[0], currentCoordinates[1]];
            Field.GameField[currentCoordinates[0], currentCoordinates[1]] = ' ';
            Field.GameField[newCoords[0], newCoords[1]] = pawnSymbol;
        }

        /// <summary>
        /// Output for entering users input.
        /// </summary>
        /// <param name="figureLetter">The figure to be waited for input.</param>
        static void ProcessFigure(char figureLetter)
        {
            bool isExecuted = false;
            while (!isExecuted)
            {
                Console.BackgroundColor = ConsoleColor.DarkGreen;
                if (figureLetter == 'K')
                {
                    Console.Write("Please enter king's turn: ");
                }
                else
                {
                    Console.Write("Please enter pawn's turn: ");
                }
                Console.ResetColor();
                string input = Console.ReadLine();
                if (input != null)
                {
                    input = input.ToUpper();
                    ExecuteCommand(input, out isExecuted);
                }
            }

            Start(MovesCounter);
        }
    }
}
