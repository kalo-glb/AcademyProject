﻿using System;

namespace KingSurvivalGame
{
    class StartGame : Engine
    {
        static void Main()
        {
            Start(MovesCounter);
            Console.WriteLine("\nThank you for using this game!\n\n");
        }
    }
}
