﻿using System;

namespace KingSurvivalGame
{
    public class King : Engine
    {
        /// <summary>
        /// Move the king into the given position
        /// </summary>
        /// <param name="verticalDirection">Vertical position</param>
        /// <param name="horizontalDirection">Horizontal position</param>
        public static void MoveKing(char verticalDirection, char horizontalDirection)
        {
            int[] kingOldPosition = new int[2];
            kingOldPosition[0] = Field.KingPosition[0];
            kingOldPosition[1] = Field.KingPosition[1];

            int[] kingNewPosition;
            bool isThereNextKingPosition = CheckNextKingPosition(
                kingOldPosition, verticalDirection,
                horizontalDirection, out kingNewPosition);

            // If there are next valid position - move the king there
            if (isThereNextKingPosition)
            {
                Field.KingPosition[0] = kingNewPosition[0];
                Field.KingPosition[1] = kingNewPosition[1];
            }
        }

        /// <summary>
        /// Check if the king can exit the field (at the top) from these coordinates
        /// </summary>
        /// <param name="coordinatesToCheck">The coordinate to check from.</param>
        private static void CheckForKingExit(int coordinatesToCheck)
        {
            if (coordinatesToCheck == 2)
            {
                Console.WriteLine("End!");
                Console.WriteLine("King wins in {0} moves!", MovesCounter / 2);
                GameIsOver = true;
            }
        }

        /// <summary>
        /// Check if the given direction for the king is avalible.
        /// </summary>
        /// <param name="currentCoordinates">Current given coordinate.</param>
        /// <param name="firstDirection">Vertical direction.</param>
        /// <param name="secondDirection">Horizontal direction.</param>
        /// <param name="newCoords">Coordinates to be written on if there
        /// are avalible position.
        /// </param>
        private static bool CheckNextKingPosition(
            int[] currentCoordinates, char firstDirection,
            char secondDirection, out int[] newCoords)
        {
            newCoords = new int[2];
            int[,] displasments = new int[,] { { -1, -2 }, { -1, 2 }, { 1, -2 }, { 1, 2 } };

            if (firstDirection == 'U')
            {
                if (secondDirection == 'L')
                {
                    return MakeKingTurn(0, newCoords, displasments, currentCoordinates);
                }
                else
                {
                    return MakeKingTurn(1, newCoords, displasments, currentCoordinates);
                }
            }
            else
            {
                if (secondDirection == 'L')
                {
                    return MakeKingTurn(2, newCoords, displasments, currentCoordinates);
                }
                else
                {
                    return MakeKingTurn(3, newCoords, displasments, currentCoordinates);
                }
            }
        }

        /// <summary>
        /// Check if the king next move will be his last in any kind.
        /// </summary>
        /// <param name="displasmentIndex">The index of the displacements for the next move.</param>
        /// <param name="newCoords">The new coordinates</param>
        /// <param name="displasments">All displacements.</param>
        /// <param name="currentCoordinates">Current king coordinates.</param>
        /// <returns></returns>
        private static bool MakeKingTurn(
            int displasmentIndex, int[] newCoords,
            int[,] displasments, int[] currentCoordinates)
        {
            newCoords[0] = currentCoordinates[0] + displasments[displasmentIndex, 0];
            newCoords[1] = currentCoordinates[1] + displasments[displasmentIndex, 1];
            if (CheckCoordinates(newCoords) && Field.GameField[newCoords[0], newCoords[1]] == ' ')
            {
                char sign = Field.GameField[currentCoordinates[0], currentCoordinates[1]];
                Field.GameField[currentCoordinates[0], currentCoordinates[1]] = ' ';
                Field.GameField[newCoords[0], newCoords[1]] = sign;
                MovesCounter++;
                for (int i = 0; i < Field.KingExistingMoves.Length; i++)
                {
                    Field.KingExistingMoves[i] = true;
                }

                CheckForKingExit(newCoords[0]);
                return true;
            }
            else
            {
                Field.KingExistingMoves[displasmentIndex] = false;
                bool allAreFalse = true;
                for (int i = 0; i < Field.KingExistingMoves.Length; i++)
                {
                    if (Field.KingExistingMoves[i] == true)
                    {
                        allAreFalse = false;
                    }
                }

                if (allAreFalse)
                {
                    GameIsOver = true;
                    Console.WriteLine("King loses!");
                    return false;
                }

                Console.BackgroundColor = ConsoleColor.DarkYellow;
                Console.WriteLine("You can't go in this direction! ");
                Console.ResetColor();
                return false;
            }
        }
    }
}
